<?php

namespace MyVendor\StoreInventory\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class EventsRepository
 *
 * @package MyVendor\StoreInventory\Domain\Repository
 */
class EventsRepository extends Repository
{

}