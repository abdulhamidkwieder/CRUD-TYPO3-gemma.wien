<?php

namespace Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

class Event extends AbstractEntity {
    /**
     * The Title of the Event
     * 
     * @var string
     */
    protected $title = '';

    /**
     * Events constructor.
     * 
     * @param string $title
     * 
     */
    public function __construct($title = '') {
            $this->setTitle($title);  
    }   

    /**
     * sets the title of the event
     * 
     * @param string $title
     */
    public function setTitle(string $title) {
        $this->title = $title;
    }

    /**
     * Gets the title of the event
     * 
     * @return string
     */
    public function getTitle() {
        return $this->title;
    }
}