<?php

namespace Events\Classes\Controller;

use Events\Classes\Domain\Repository\EventsRepository;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class StoreInventoryController
 *
 * @package Events\Classes\Controller
 */
class eventController extends ActionController
{

    /**
     * @var eventsRepository
     */
    private $eventsRepository;

    /**
     * Inject the events repository
     *
     * @param \Events\Classes\Domain\Repository\eventsRepository $eventsRepository
     */
    public function injectEventsRepository(eventsRepository $eventsRepository)
    {
        $this->eventsRepository = $eventsRepository;
    }

    /**
     * List Action
     *
     * @return void
     */
    public function listAction()
    {
        $events = $this->eventsRepository->findAll();
        $this->view->assign('events', $events);
    }
}