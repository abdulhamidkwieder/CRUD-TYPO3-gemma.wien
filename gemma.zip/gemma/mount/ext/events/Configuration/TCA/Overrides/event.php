<xml version="1.0" encoding="UTF-8"?>
<xliff version="1.0">
   <file source-language="en" datatype="plaintext" original="messages" date="2017-11-27T17:38:32Z"
        product-name="store_inventory">
      <header/>
      <body>
         <trans-unit id="extension.title">
            <source>store</source>
         </trans-unit>
         <trans-unit id="tx_storeinventory_domain_model_event">
            <source>Event</source>
         </trans-unit>
         <trans-unit id="tx_storeinventory_domain_model_event.item_label">
            <source>Item Label</source>
         </trans-unit>
      </body>
   </file>
</xliff>