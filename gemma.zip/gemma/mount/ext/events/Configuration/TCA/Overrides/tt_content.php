<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'Events.EventsInventory',
    'pil',
    'The Events List',
    'EXT:store_inventory/Resources/Public/Icons/Extension.svg'
);