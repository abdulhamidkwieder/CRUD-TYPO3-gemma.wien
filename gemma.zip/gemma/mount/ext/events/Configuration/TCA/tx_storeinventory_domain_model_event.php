<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:store_inventory/resources/Private/Language/locallang_db.xlf:tc_storienventory_domain_model_event',
        'label' => 'EXT:store_inventory/Resources/Public/Icons/Product.svg'
    ],
'columns' => [
    'title' => [
        'label' => 'LLL:EXT:store_inventory/Resources/Private/Language/locallang_db.xlf:tx_storeinventory_domain_model_event.item_label',
        'config' => [
           'type' => 'input',
           'size' => '20',
           'eval' => 'trim'
        ],
    ],
],
'types' => [
    '0' => ['showitem' => 'title'],
 ],
];