<?php
defined('TYPO3_MODE') or die();

call_user_func(
    function ($extKey) {
    },
    'events'
);
