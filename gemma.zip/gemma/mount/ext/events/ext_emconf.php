<?php

$EM_CONF['events'] = [
    'title' => 'Earlybird events',
    'description' => 'Earlybird site configuration extension.',
    'version' => '9.5.3',
    'state' => 'stable',
    'constraints' => [
        'depends' => [
            'typo3' => '9.5.3-9.5.99',
            'sitebase' => '9.5.3-9.5.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
