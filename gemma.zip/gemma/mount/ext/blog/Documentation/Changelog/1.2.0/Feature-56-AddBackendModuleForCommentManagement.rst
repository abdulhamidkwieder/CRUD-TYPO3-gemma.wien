.. include:: ../../Includes.txt

================================================================
Feature: #EXTBLOG-56 - Add Backend Module for comment management
================================================================

See https://jira.typo3.com/browse/EXTBLOG-56

See https://jira.typo3.com/browse/TE-15

Description
===========

The backend module contains a new comment management module.


Impact
======

With new backend module it is possible to search and filter blog comments.

.. index:: Backend, JavaScript
