.. include:: ../../Includes.txt

=============================================================
Feature: #EXTBLOG-55 - Add Backend Module for post management
=============================================================

See https://jira.typo3.com/browse/EXTBLOG-55

See https://jira.typo3.com/browse/TE-14

Description
===========

The backend module contains a new post management module.


Impact
======

With new backend module it is possible to search and filter blog post, jump to the edit mode of a post, tag or category.

.. index:: Backend, JavaScript
