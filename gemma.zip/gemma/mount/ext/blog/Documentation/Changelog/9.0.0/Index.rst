
.. include:: ../../Includes.txt

Changes in version 9.0.0
========================

**Table of contents**

.. contents::
   :local:
   :depth: 1

Breaking Changes
^^^^^^^^^^^^^^^^

.. toctree::
   :maxdepth: 1
   :titlesonly:
   :glob:

   Breaking-*

Features
^^^^^^^^

.. toctree::
   :maxdepth: 1
   :titlesonly:
   :glob:

   Feature-*

Deprecation
^^^^^^^^^^^

.. toctree::
   :maxdepth: 1
   :titlesonly:
   :glob:

   Deprecation-*
