.. include:: ../../Includes.txt

========================================================================
Feature: #EXTBLOG-122 - AvatarProvider selectable on author record level
========================================================================

See https://jira.typo3.com/browse/EXTBLOG-122

Description
===========

It is now possible to select the AvatarProvider on author record level.
This means every author can use another AvatarProvider.

.. index:: Backend, Frontend, Database
