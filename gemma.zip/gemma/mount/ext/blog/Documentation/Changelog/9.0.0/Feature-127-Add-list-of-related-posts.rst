.. include:: ../../Includes.txt

=================================================
Feature: #EXTBLOG-127 - Add list of related posts
=================================================

See https://jira.typo3.com/browse/EXTBLOG-127

Description
===========

It is now possible to add a list of related posts based on the current
showed post.

The related posts are based on matching categories and tags. You can
configure the "weight" of categories and tags to match it to your needs.

.. index:: Backend, Frontend
