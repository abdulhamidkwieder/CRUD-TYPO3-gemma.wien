# buildsettings.sh

# absolute path, or relative to conf.py, without suffix (.rst)
MASTERDOC=../Index

# absolute path, or relative to conf.py
BUILDDIR=./build

# absolute path, or relative to conf.py
LOGDIR=./_not_versioned
