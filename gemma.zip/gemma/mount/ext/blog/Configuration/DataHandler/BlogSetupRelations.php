<?php

/*
 * This file is part of the package t3g/blog.
 *
 * For the full copyright and license information, please read the
 * LICENSE file that was distributed with this source code.
 */

$data = [];

// Tag and Category relation
$data['pages']['NEW_firstBlogPostPage']['tags'] = 'NEW_blogTagTYPO3';
$data['pages']['NEW_firstBlogPostPage']['categories'] = 'NEW_blogCategoryTYPO3';

return $data;
