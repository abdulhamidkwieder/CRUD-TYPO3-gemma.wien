<?php

$GLOBALS['TYPO3_CONF_VARS']['SYS']['sitename'] .= ' [LIVE]';

// [SYS][devIPmask]: List of IP addresses; blank value will deny all, '*' will allow all.
$GLOBALS['TYPO3_CONF_VARS']['SYS']['devIPmask'] = '';
// [SYS][displayErrors]: -1=Do not set, 0=LIVE, 1=Display errors using [SYS][errorHandler]
$GLOBALS['TYPO3_CONF_VARS']['SYS']['displayErrors'] = 0;
// [SYS][systemLogLevel]: 0=Info, 1=Notice, 2=Warning, 3=Error, 4=Fatal Error
$GLOBALS['TYPO3_CONF_VARS']['SYS']['systemLogLevel'] = 4;
/**  [SYS][systemMaintainers]; 
 * 1 = root
 * 2 = tig
 * 3 = him
 * 6 = stm
*/
$GLOBALS['TYPO3_CONF_VARS']['SYS']['systemMaintainers'] = [1,2,3,6];
// [FE][debug]: boolean
$GLOBALS['TYPO3_CONF_VARS']['FE']['debug'] = false;
// [BE][debug]: boolean
$GLOBALS['TYPO3_CONF_VARS']['BE']['debug'] = false;

//mail server for production environment
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport'] = 'smtp';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_server'] = 'mail.chirping.net:456';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_username'] = 'typo3-dummy@rlybrd.at';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_password'] = 'ThisIsTesting0nly';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] = 'typo3-dummy@rlybrd.at';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromName'] = 'Earlybird TYPO3 System';


// google_signin configuration
$GLOBALS['TYPO3_CONF_VARS']['EXTENSIONS']['google_signin']['clientId'] = '528849169900-eanrhud674707dtlum4omhmsbkhlaeai.apps.googleusercontent.com';
$GLOBALS['TYPO3_CONF_VARS']['EXTENSIONS']['google_signin']['enableBE'] = 1;