SET NAMES utf8;


# UPDATE `sys_domain` SET `domainName` = 'typo3-gemma.eb.dev' WHERE uid = 1;
# UPDATE `sys_domain` SET `domainName` = 'gemma.eb.dev' WHERE uid = 2;
