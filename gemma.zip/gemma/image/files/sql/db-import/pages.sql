
SET NAMES utf8;


UPDATE `pages` SET `url` = 'typo3-gemma.eb.dev/typo3' WHERE uid = 1;
