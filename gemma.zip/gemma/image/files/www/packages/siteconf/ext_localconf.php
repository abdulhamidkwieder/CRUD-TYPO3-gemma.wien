<?php
defined('TYPO3_MODE') or die();

call_user_func(
    function ($extKey) {
        // Add Page TSConfig
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            '@import \'EXT:' . $extKey . '/Configuration/TsConfig/Page.tsconfig\''
        );

        // Add User TSConfig
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addUserTSConfig(
            '@import \'EXT:' . $extKey . '/Configuration/TsConfig/User.tsconfig\''
        );
    },
    'siteconf'
);
