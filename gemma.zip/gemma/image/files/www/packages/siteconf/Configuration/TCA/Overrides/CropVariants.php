<?php
defined('TYPO3_MODE') or die();

/**
 * Crop variants for EXT:news records
 */
if (true === \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('news')) {
    if (true === isset($GLOBALS['TCA']['tx_news_domain_model_news']['types'])) {
        $cropVariants = [
            '1:1' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_SQUARE,
            '4:3' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_4_TO_3,
            '3:2' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_3_TO_2,
            '16:9' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_16_TO_9,
            '32:9' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_32_TO_9,
            'social' => \Earlybird\Sitebase\Utility\ConfigurationUtility::CROP_VARIANT_SOCIAL,
        ];
        foreach ($GLOBALS['TCA']['tx_news_domain_model_news']['types'] as $typeId => $typeDefinition) {
            $GLOBALS['TCA']['tx_news_domain_model_news']['types'][$typeId]['columnsOverrides']['fal_media']['config']['overrideChildTca']['columns']['crop']['config']['cropVariants'] = $cropVariants;
        }
    }
}
