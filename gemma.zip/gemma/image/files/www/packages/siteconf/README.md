# EXT:siteconf

Configuration extension for TYPO3 website https://{$VIRTUAL_HOST_FE}
