<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'Impexp test extension',
    'description' => '',
    'category' => '',
    'version' => '9.5.4',
    'state' => 'beta',
    'uploadfolder' => 1,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'Marc Bastian Heinrichs',
    'author_email' => 'mbh@mbh-software.de',
    'author_company' => '',
    'constraints' => [
        'depends' => [
            'typo3' => '9.5.4',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
