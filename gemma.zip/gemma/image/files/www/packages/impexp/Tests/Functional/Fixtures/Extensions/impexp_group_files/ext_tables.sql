#
# Table structure for table 'tx_impexpgroupfiles_item'
#
CREATE TABLE tx_impexpgroupfiles_item (
	title tinytext NOT NULL,
	images text NOT NULL,
	image_references text NOT NULL,
	flexform text NOT NULL
);


