#!/bin/bash


sudo -u www-admin ln -sf /data/FAL /var/www/FALL