<?php
/** @var string $_EXTKEY */

/**
 * @var array $EM_CONF
 * @see https://docs.typo3.org/typo3cms/CoreApiReference/latest/ExtensionArchitecture/DeclarationFile/
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'Things (schema.org)',
    'description' => 'Generic TYPO3 extension to manage and display things like persons, organizations, etc. based on http://schema.org/Thing.',
    'version' => '8.7.0',
    'state' => 'stable',
];
