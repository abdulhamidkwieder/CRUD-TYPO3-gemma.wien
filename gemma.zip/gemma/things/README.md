# EXT:things

Generic TYPO3 extension to manage and display things like persons, organizations, etc. based on [schema.org/Thing](http://schema.org/Thing).

* [Project Page](https://src.earlybird.at/typo3/things)
* [Issues](https://pm.earlybird.at/projects/eb-ext-thing/issues)


## FAQ

### Plugin 'List': Sorting

Use `plugin.tx_things_list.settings.constraint.orderings` to define one or more orderings.
Each ordering must provide a `property` name and an order `direction` (`ASC` (default) or `DESC`):

```typo3_typoscript
# TS Setup
plugin.tx_things_list.settings.constraint.orderings {
    0 {
        property = name
        direction = ASC
    }
}
```

To access properties from the object tree hierarchy (child records, related records) use path notation 
for `property`:

```typo3_typoscript
# TS Setup
plugin.tx_things_list.settings.constraint.orderings {
    0 {
        property = primaryPostalAddress.code
        direction = ASC
    }
    1 {
        property = name
        direction = ASC
    }
}
```

### Plugin 'List': Category constraint

Use `plugin.tx_things_list.settings.constraint.categories` to define one or more category constraints.
Each constraint must provide `uids` (a CSV list of category UIDs) and a `conjunction` mode:
* `OR`:     Include records which belong to at least one of the given categories
* `AND`:    Include records which belong to all of the given categories
* `NOR`:    Include records which don't belong to any of the given categories
* `NAND`:   Include records which belong to none of the given categories

```typo3_typoscript
# TS Setup for a single category constraint
plugin.tx_things_list.settings.constraint.categories {
    0 {
        uids = 1,2,3
        conjunction = OR
    }
}
```

Multiple constraints get combined using logical `AND`. The following example configuration will
return all records which *do not* have a relation to category `1` and category `2` (`...constraint.categories.0`)
*and* have either a realation to category `3` *or* category `4` (`...constraint.categories.1`).

```typo3_typoscript
# TS Setup for multiple category constraints
plugin.tx_things_list.settings.constraint.categories {
    0 {
        uids = 1,2
        conjunction = NOR
    }
    1 {
        uids = 3,4
        conjunction = OR
    }
}
```

### Restrict the category tree

```typo3_typoscript
# Set the category root using Page TSconfig
TCEFORM.tx_things_domain_model_thing.categories.config.treeConfig.rootUid = 45
```
`rootUid` is the UID of the category record (`sys_category.uid`) which should be used as
tree root instead of 'Categories'.
