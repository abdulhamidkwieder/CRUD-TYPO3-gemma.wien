<?php
/** @var string $_EXTKEY */
defined('TYPO3_MODE') or die();

call_user_func(
    /**
     * @param string $extKey
     */
    function ($extKey)
    {

    },
    $_EXTKEY
);
