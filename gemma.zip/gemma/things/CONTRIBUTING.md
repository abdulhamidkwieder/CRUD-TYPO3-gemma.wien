Please respect [Earlybird's Contribution Guide](https://src.earlybird.at/docs/earlybird/wikis/typo3/contributing)!
