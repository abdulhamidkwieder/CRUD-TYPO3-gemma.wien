<?php
declare(strict_types=1);
namespace Earlybird\Things\ViewHelpers\Widget\Controller;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Fluid\ViewHelpers\Widget\Controller\PaginateController as TYPO3PaginateController;
use TYPO3\CMS\Extbase\Persistence\QueryResultInterface;

/**
 * Class PaginateController
 * @see https://github.com/TYPO3/TYPO3.CMS/blob/TYPO3_8-7/typo3/sysext/fluid/Classes/ViewHelpers/Widget/Controller/PaginateController.php
 */
class PaginateController extends TYPO3PaginateController
{
    /** @var int */
    protected $initialOffset = 0;

    /**
     * @return void
     */
    public function initializeAction()
    {
        parent::initializeAction();

        if (
            true === isset($this->widgetConfiguration['configuration']['offset'])
            && 0 < (int)$this->widgetConfiguration['configuration']['offset']
        ) {
            $this->initialOffset = (int)$this->widgetConfiguration['configuration']['offset'];
        }
    }

    /**
     * @param int $currentPage
     * @return void
     */
    public function indexAction($currentPage = 1)
    {
        // set current page
        $this->currentPage = (int)$currentPage;
        if ($this->currentPage < 1) {
            $this->currentPage = 1;
        }
        if ($this->currentPage > $this->numberOfPages) {
            // set $modifiedObjects to NULL if the page does not exist
            $modifiedObjects = null;
        } else {
            // modify query
            $itemsPerPage = (int)$this->configuration['itemsPerPage'];
            $offset = 0;
            if ($this->currentPage > 1) {
                $offset = ((int)($itemsPerPage * ($this->currentPage - 1)));
                $totalObjects = count($this->objects);
                if (($itemsPerPage + $offset) >= $totalObjects) {
                    $itemsPerPage = $totalObjects - $offset;
                }
            }
            $objectOffset = $offset;
            if (
                $this->objects instanceof QueryResultInterface
                && 0 < $this->initialOffset
            ) {
                $objectOffset += $this->initialOffset;
            }
            $modifiedObjects = $this->prepareObjectsSlice($itemsPerPage, $objectOffset);
        }
        $pagination = $this->buildPagination();
        $this->view->assign('contentArguments', [
            $this->widgetConfiguration['as'] => $modifiedObjects,
            'pagination' => $pagination,
        ]);
        $this->view->assign('configuration', $this->configuration);
        $this->view->assign('pagination', $pagination);
    }

    /**
     * Add some extra item specific data to TYPO3's default pagination data.
     *
     * @return array
     */
    protected function buildPagination()
    {
        $pagination = parent::buildPagination();

        $totalItems = count($this->objects);
        $index = ($this->currentPage - 1) * (int)$this->configuration['itemsPerPage'];
        $cycle = $index + 1;
        // Set to NULL if a non existing page is requested
        if ($cycle > $totalItems) {
            $index = null;
            $cycle = null;
        }

        $pagination['iteration'] = [
            'index' => $index,
            'cycle' => $cycle,
            'total' => $totalItems,
        ];

        return $pagination;
    }
}
