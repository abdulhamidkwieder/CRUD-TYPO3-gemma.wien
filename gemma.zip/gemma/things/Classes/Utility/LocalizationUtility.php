<?php
declare(strict_types=1);
namespace Earlybird\Things\Utility;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Lang\LanguageService;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility as TYPO3LocalizationUtility;

class LocalizationUtility {
    /**
     * Path to main XLF file
     */
    const LLL = 'LLL:EXT:things/Resources/Private/Language/locallang.xlf:';

    /**
     * @param string $input Label key/reference
     *
     * @return string
     */
    public static function sL($input): string
    {
        return self::getLanguageService()->sL($input);
    }

    /**
     * Wrapper call to Extbase's LocalizationUtility
     *
     * @param string $id Translation Key compatible to TYPO3 Flow
     * @param array $arguments Arguments to be replaced in the resulting string
     *
     * @return string|null
     */
    public static function translate($id, $arguments = null): ?string
    {
        return TYPO3LocalizationUtility::translate($id, 'Things', $arguments);
    }

    /**
     * @return LanguageService
     */
    public static function getLanguageService(): LanguageService
    {
        if (
            false === isset($GLOBALS['LANG'])
            || false === is_a($GLOBALS['LANG'], LanguageService::class)
        ) {
            $languageService = GeneralUtility::makeInstance(LanguageService::class);
        } else {
            $languageService = $GLOBALS['LANG'];
        }

        return $languageService;
    }
}