<?php
declare(strict_types=1);
namespace Earlybird\Things\Backend\Tca;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Backend\Utility\BackendUtility;
use Earlybird\Things\Utility\LocalizationUtility;

/**
 * Generates a custom record title by combining several database fields.
 *
 * For use as 'label_userFunc' => \Earlybird\Things\Backend\Tca\EmailAddressLabel::class . '->getLabel',
 */
class EmailAddressLabel
{
    /**
     * Get the record title.
     *
     * @param array $parameters     Parameters passed by reference.
     * @param object $parentObject  A reference to the parent object.
     *
     * @return void
     */
    public function getLabel(
        &$parameters,
        /** @noinspection PhpUnusedParameterInspection */
        $parentObject
    ): void
    {
        $record = BackendUtility::getRecord($parameters['table'], $parameters['row']['uid']);

        $label = (string)$record['email'];
        $type = LocalizationUtility::sL(LocalizationUtility::LLL . 'entities.emailaddress.type.options.' . $record['type']);
        if (false === empty($type)) {
            $label .= ' (' . $type . ')';
        }

        // Assign new label
        $parameters['title'] = trim($label);
    }
}
