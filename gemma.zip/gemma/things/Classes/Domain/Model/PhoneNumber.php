<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

class PhoneNumber extends AbstractEntity
{
    /** @var string */
    protected $number = '';

    /** @var int */
    protected $type = 0;

    /** @var int */
    protected $sortingForeign = 0;

    /**
     * @return string
     */
    public function getNumber(): string
    {
        return $this->number;
    }

    /**
     * @return string
     */
    public function getUri(): string
    {
        if ('+' === substr($this->number, 0 ,1)) {
            $uri = '+' . preg_replace('/[^0-9-]/', '', $this->number);
        } else {
            $uri = preg_replace('/[^0-9-]/', '', $this->number);
        }

        return $uri;
    }

    /**
     * @return int
     */
    public function getType(): int
    {
        return $this->type;
    }

    /**
     * @return int
     */
    public function getSortingForeign(): int
    {
        return $this->sortingForeign;
    }

}
