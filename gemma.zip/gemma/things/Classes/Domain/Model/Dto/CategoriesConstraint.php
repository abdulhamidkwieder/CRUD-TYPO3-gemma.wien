<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model\Dto;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

class CategoriesConstraint extends AbstractEntity
{
    /** @var array */
    protected $uids = [];

    /** @var string */
    protected $conjunction = 'OR';

    /**
     * @return array
     */
    public function getUids(): array
    {
        return $this->uids;
    }

    /**
     * @param array $uids
     */
    public function setUids(array $uids): void
    {
        $uids = GeneralUtility::intExplode(',', implode(',', $uids), true);
        $this->uids = array_unique($uids);
    }

    /**
     * @return string
     */
    public function getConjunction(): string
    {
        return $this->conjunction;
    }

    /**
     * @param string $conjunction
     */
    public function setConjunction(string $conjunction): void
    {
        $conjunction = strtoupper($conjunction);
        if (1 !== preg_match('/^(OR|NOR|AND|NAND)$/', $conjunction)) {
            $conjunction = 'OR';
        }

        $this->conjunction = $conjunction;
    }
}
