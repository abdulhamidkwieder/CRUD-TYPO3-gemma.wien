<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model\Dto;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Earlybird\Things\Service\SettingsService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;

class FindThingsConstraint extends AbstractEntity
{
    /** @var SettingsService */
    protected $settingsService = null;

    /** @var array */
    protected $settings = null;

    /** @var int */
    protected $limit = 99999;

    /** @var int */
    protected $offset = 0;

    /** @var array */
    protected $orderings = [];

    /** @var array */
    protected $uids = [];
    
    /** @var string */
    protected $searchTerms = '';

    /** @var array */
    protected $uuids = [];

    /** @var array */
    protected $types = [];

    /** @var array */
    protected $subtypes = [];

    /** @var array */
    protected $categories = [];

    /** @var array */
    protected $primaryPostalAddressCodes = [];

    /**
     * Default constructor
     */
    public function __construct()
    {
        $this->settingsService = GeneralUtility::makeInstance(SettingsService::class);
        $this->settings = $this->settingsService->getTsSettings();
    }

    /**
     * @return int
     */
    public function getLimit(): int
    {
        return $this->limit;
    }

    /**
     * @param int $limit
     */
    public function setLimit(int $limit = null): void
    {
        $limit = (int)$limit;
        // We allow limit to be '0' to e.g. disable output via conditional TypoScript
        $limit = (0 > $limit) ? 99999 : $limit;

        $this->limit = $limit;
    }

    /**
     * @return int
     */
    public function getOffset(): int
    {
        return $this->offset;
    }

    /**
     * @param int $offset
     */
    public function setOffset(int $offset = null): void
    {
        $offset = (int)$offset;
        $offset = (0 > $offset) ? 0 : $offset;

        $this->offset = $offset;
    }

    /**
     * @return array
     */
    public function getOrderings(): array
    {
        return $this->orderings;
    }

    /**
     * Sets the property names to order the result by. Expected like this:
     * array(
     *   array(
     *     'property' => foo,
     *     'direction' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
     *   ),
     *   array(
     *     'property' => bar,
     *     'direction' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING,
     *   ),
     * );
     *
     * @param array $orderings
     */
    public function setOrderings(array $orderings): void
    {
        $checkedOrderings = [];

        foreach ($orderings as $orderingSettings) {
            if (
                true === isset($orderingSettings['property'])
                && false === empty((string)$orderingSettings['property'])
            ) {
                $property = (string)$orderingSettings['property'];
                if (
                    true === isset($orderingSettings['direction'])
                    && false === empty((string)$orderingSettings['direction'])
                ) {
                    $direction = (string)$orderingSettings['direction'];
                }
                if (QueryInterface::ORDER_DESCENDING !== $direction) {
                    $direction = QueryInterface::ORDER_ASCENDING;
                }
                $checkedOrderings[$property] = $direction;
            }
        }

        $this->orderings = $checkedOrderings;
    }

    /**
     * @return array
     */
    public function getUuids(): array
    {
        return $this->uuids;
    }

    /**
     * @param array $uuids
     */
    public function setUuids(array $uuids): void
    {
        $this->uuids = $uuids;
    }

    /**
     * @return array
     */
    public function getUids(): array
    {
        return $this->uids;
    }

    /**
     * @param array $uids
     */
    public function setUids(array $uids): void
    {
        $this->uids = $uids;
    }

    /**
     * @return array
     */
    public function getTypes(): array
    {
        return $this->types;
    }

    /**
     * @param array $types
     */
    public function setTypes(array $types): void
    {
        $this->types = $types;
    }

    /**
     * @return array
     */
    public function getSubtypes(): array
    {
        return $this->subtypes;
    }

    /**
     * @param array $subtypes
     */
    public function setSubtypes(array $subtypes): void
    {
        $this->subtypes = $subtypes;
    }

    /**
     * @return array
     */
    public function getCategories(): array
    {
        return $this->categories;
    }

    /**
     * Sets the category constraints. Expected like this:
     * array(
     *   array(
     *     'uids' => 1,2,3,
     *     'conjunction' => OR,
     *   ),
     *   array(
     *     'uids' => 4,5,6,
     *     'direction' => NOR,
     *   ),
     * );
     *
     * @param array $categoryConstraints
     */
    public function setCategories(array $categoryConstraints): void
    {
        $categories = [];
        foreach ($categoryConstraints as $categoryConstraintSettings) {
            if (
                true === isset($categoryConstraintSettings['uids'])
                && false === empty($categoryConstraintSettings['uids'])
            ) {
                $categoryUids = GeneralUtility::intExplode(',', (string)$categoryConstraintSettings['uids'], true);
                $conjunction = (true === isset($categoryConstraintSettings['conjunction'])) ? (string)$categoryConstraintSettings['conjunction'] : 'OR';
                $categoryConstraint = new CategoriesConstraint();
                $categoryConstraint->setUids($categoryUids);
                $categoryConstraint->setConjunction($conjunction);
                $categories[] = $categoryConstraint;
            }
        }

        $this->categories = $categories;
    }

    /**
     * @return array
     */
    public function getPrimaryPostalAddressCodes(): array
    {
        return $this->primaryPostalAddressCodes;
    }

    /**
     * @param array $primaryPostalAddressCodes
     */
    public function setPrimaryPostalAddressCodes(array $primaryPostalAddressCodes): void
    {
        if (true === in_array('NONEMPTY', $primaryPostalAddressCodes)) {
            $primaryPostalAddressCodes = ['NONEMPTY'];
        }

        $this->primaryPostalAddressCodes = $primaryPostalAddressCodes;
    }
    
    /**
     * @return string
     */
    public function getSearchTerms(): string
    {
        return $this->searchTerms;
    }

    /**
     * @param string $searchTerms
     */
    public function setSearchTerms(string $searchTerms): void
    {
        $checkedSearchTerms = [];

        $this->searchTerms = $searchTerms;
    }
}
