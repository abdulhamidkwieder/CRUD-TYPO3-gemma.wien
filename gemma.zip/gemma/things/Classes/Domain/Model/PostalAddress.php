<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

class PostalAddress extends AbstractEntity
{
    /** @var string */
    protected $street = '';

    /** @var string */
    protected $extended = '';

    /** @var string */
    protected $code = '';

    /** @var string */
    protected $locality = '';

    /** @var string */
    protected $region = '';

    /** @var string */
    protected $country = '';

    /** @var double */
    protected $latitude = 0.0;

    /** @var double */
    protected $longitude = 0.0;

    /** @var int */
    protected $type = 0;

    /** @var int */
    protected $sortingForeign = 0;

    /**
     * @return string
     */
    public function getStreet(): string
    {
        return $this->street;
    }

    /**
     * @return string
     */
    public function getExtended(): string
    {
        return $this->extended;
    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @return string
     */
    public function getLocality(): string
    {
        return $this->locality;
    }

    /**
     * @return string
     */
    public function getRegion(): string
    {
        return $this->region;
    }

    /**
     * @return string
     */
    public function getCountry(): string
    {
        return $this->country;
    }

    /**
     * @return float
     */
    public function getLatitude(): float
    {
        return $this->latitude;
    }

    /**
     * @return float
     */
    public function getLongitude(): float
    {
        return $this->longitude;
    }

    /**
     * @return int
     */
    public function getType(): int
    {
        return $this->type;
    }

    /**
     * @return int
     */
    public function getSortingForeign(): int
    {
        return $this->sortingForeign;
    }
}
