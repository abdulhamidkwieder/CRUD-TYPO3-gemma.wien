<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

class EmailAddress extends AbstractEntity
{
    /** @var string */
    protected $email = '';

    /** @var int */
    protected $type = 0;

    /** @var int */
    protected $sortingForeign = 0;

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return int
     */
    public function getType(): int
    {
        return $this->type;
    }

    /**
     * @return int
     */
    public function getSortingForeign(): int
    {
        return $this->sortingForeign;
    }
}
