<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Model;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Earlybird\Things\Domain\Repository\PostalAddressRepository;
use Earlybird\Things\Domain\Repository\EmailAddressRepository;
use Earlybird\Things\Domain\Repository\PhoneNumberRepository;
use Earlybird\Things\Domain\Repository\FaxNumberRepository;
use Earlybird\Things\Service\SettingsService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;
use TYPO3\CMS\Extbase\Persistence\ObjectStorage;

class Thing extends AbstractEntity
{
    /** @var string */
    protected $uuid = '';

    /** @var string */
    protected $identifier = '';

    /** @var string */
    protected $name = '';

    /** @var string */
    protected $type = '';

    /** @var string */
    protected $subtype = '';

    /** @var string */
    protected $abstract = '';

    /** @var string */
    protected $description = '';

    /** @var string */
    protected $familyName = '';

    /** @var string */
    protected $givenName = '';

    /** @var string */
    protected $honorificPrefix = '';

    /** @var string */
    protected $honorificSuffix = '';

    /** @var string */
    protected $title = '';

    /** @var int */
    protected $gender = 0;

    /** @var \DateTime */
    protected $birthDate = null;

    /** @var string */
    protected $website = '';

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\PostalAddress>
     * @lazy
     */
    protected $postalAddresses = null;

    /**
     * @var ObjectStorage
     * @transient
     */
    protected $filteredPostalAddresses = null;

    /** @var \Earlybird\Things\Domain\Model\PostalAddress */
    protected $primaryPostalAddress = null;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\EmailAddress>
     * @lazy
     */
    protected $emailAddresses = null;

    /** @var \Earlybird\Things\Domain\Model\EmailAddress */
    protected $primaryEmailAddress = null;

    /**
     * @var ObjectStorage
     * @transient
     */
    protected $filteredEmailAddresses = null;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\PhoneNumber>
     * @lazy
     */
    protected $phoneNumbers = null;

    /**
     * @var ObjectStorage
     * @transient
     */
    protected $filteredPhoneNumbers = null;

    /** @var \Earlybird\Things\Domain\Model\PhoneNumber */
    protected $primaryPhoneNumber = null;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\FaxNumber>
     * @lazy
     */
    protected $faxNumbers = null;

    /**
     * @var ObjectStorage
     * @transient
     */
    protected $filteredFaxNumbers = null;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\Category>
     * @lazy
     */
    protected $categories;

    /** @var ObjectStorage */
    protected $sortedCategories = null;

    /** @var array */
    protected $categoryGroups = [];

    /** @var array */
    protected $settings = null;

    /** @var SettingsService */
    protected $settingsService = null;

    /** @var EmailAddressRepository */
    protected $emailAddressRepository = null;

    /** @var PostalAddressRepository */
    protected $postalAddressRepository = null;

    /** @var PhoneNumberRepository */
    protected $phoneNumberRepository = null;

    /** @var FaxNumberRepository */
    protected $faxNumberRepository = null;

    function __construct()
    {
        $this->categories = new ObjectStorage();
        $this->postalAddresses = $this->getPostalAddresses();
    }

    /**
     * @param PostalAddressRepository $postalAddressRepository
     * @return void
     */
    public function injectPostalAddressRepository(PostalAddressRepository $postalAddressRepository): void
    {
        $this->postalAddressRepository = $postalAddressRepository;
    }

    /**
     * @param EmailAddressRepository $emailAddressRepository
     * @return void
     */
    public function injectEmailAddressRepository(EmailAddressRepository $emailAddressRepository): void
    {
        $this->emailAddressRepository = $emailAddressRepository;
    }

    /**
     * @param PhoneNumberRepository $phoneNumberRepository
     * @return void
     */
    public function injectPhoneNumberRepository(PhoneNumberRepository $phoneNumberRepository): void
    {
        $this->phoneNumberRepository = $phoneNumberRepository;
    }

    /**
     * @param FaxNumberRepository $faxNumberRepository
     * @return void
     */
    public function injectFaxNumberRepository(FaxNumberRepository $faxNumberRepository): void
    {
        $this->faxNumberRepository = $faxNumberRepository;
    }

    /**
     * @return array
     */
    private function getSettings(): array
    {
        if (null === $this->settingsService) {
            $this->settingsService = GeneralUtility::makeInstance(SettingsService::class);
        }
        if (null === $this->settings) {
            $tsSettings = $this->settingsService->getTsSettings();
            $this->settings = [];
            if (true === isset($tsSettings['settings']) && true === is_array($tsSettings['settings'])) {
                $this->settings = $tsSettings['settings'];
            }
        }

        return $this->settings;
    }

    /**
     * @return string
     */
    public function getUuid(): string
    {
        $uuid = (string)$this->uuid;

        // Always return the UUID of the original record
        if (39 === strlen($uuid)) {
            $uuid = substr($uuid, 0, 36);
        }

        return $uuid;
    }

    /**
     * @return string
     */
    public function getIdentifier(): string
    {
        return $this->identifier;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return (true === empty($this->type)) ? 'Thing' : $this->type;
    }

    /**
     * @return string
     */
    public function getSubtype(): string
    {
        return (string)$this->subtype;
    }

    /**
     * @return ObjectStorage
     */
    public function getPostalAddresses(): ObjectStorage
    {
        return $this->postalAddresses;
    }

    /**
     * @return ObjectStorage
     */
    public function getFilteredPostalAddresses(): ObjectStorage
    {
        if (null === $this->filteredPostalAddresses) {
            $settings = $this->getSettings();
            $settings = (true === isset($settings['fields']['postalAddresses'])) ? $settings['fields']['postalAddresses'] : [];
            $this->filteredPostalAddresses = $this->postalAddressRepository->findByParent($this->getUid(), $settings);
        }

        return $this->filteredPostalAddresses;
    }

    /**
     * @return ObjectStorage
     */
    public function getEmailAddresses(): ObjectStorage
    {
        return $this->emailAddresses;
    }

    /**
     * @return ObjectStorage
     */
    public function getFilteredEmailAddresses(): ObjectStorage
    {
        if (null === $this->filteredEmailAddresses) {
            $settings = $this->getSettings();
            $settings = (true === isset($settings['fields']['emailAddresses'])) ? $settings['fields']['emailAddresses'] : [];
            $this->filteredEmailAddresses = $this->emailAddressRepository->findByParent($this->getUid(), $settings);
        }

        return $this->filteredEmailAddresses;
    }

    /**
     * @return ObjectStorage
     */
    public function getPhoneNumbers(): ObjectStorage
    {
        return $this->phoneNumbers;
    }

    /**
     * @return ObjectStorage
     */
    public function getFilteredPhoneNumbers(): ObjectStorage
    {
        if (null === $this->filteredPhoneNumbers) {
            $settings = $this->getSettings();
            $settings = (true === isset($settings['fields']['phoneNumbers'])) ? $settings['fields']['phoneNumbers'] : [];
            $this->filteredPhoneNumbers = $this->phoneNumberRepository->findByParent($this->getUid(), $settings);
        }

        return $this->filteredPhoneNumbers;
    }

    /**
     * @return ObjectStorage
     */
    public function getFaxNumbers(): ObjectStorage
    {
        return $this->faxNumbers;
    }

    /**
     * @return ObjectStorage
     */
    public function getFilteredFaxNumbers(): ObjectStorage
    {
        if (null === $this->filteredFaxNumbers) {
            $settings = $this->getSettings();
            $settings = (true === isset($settings['fields']['faxNumbers'])) ? $settings['fields']['faxNumbers'] : [];
            $this->filteredFaxNumbers = $this->faxNumberRepository->findByParent($this->getUid(), $settings);
        }

        return $this->filteredFaxNumbers;
    }

    /**
     * @return \Earlybird\Things\Domain\Model\PostalAddress|null
     */
    public function getPrimaryPostalAddress(): ?PostalAddress
    {
        return $this->primaryPostalAddress;
    }

    /**
     * @return \Earlybird\Things\Domain\Model\EmailAddress|null
     */
    public function getPrimaryEmailAddress(): ?EmailAddress
    {
        return $this->primaryEmailAddress;
    }

    /**
     * @return \Earlybird\Things\Domain\Model\PhoneNumber|null
     */
    public function getPrimaryPhoneNumber(): ?PhoneNumber
    {
        return $this->primaryPhoneNumber;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Earlybird\Things\Domain\Model\Category>
     */
    public function getCategories()
    {
        return $this->categories;
    }

    /**
     * @return ObjectStorage
     */
    public function getSortedCategories(): ObjectStorage
    {
        if (null === $this->sortedCategories) {
            $categories = new ObjectStorage();
            $categoryObjects = [];

            foreach ($this->getCategories() as $category) {
                $categoryObjects[$category->getSorting()] = $category;
            }
            ksort($categoryObjects);
            foreach ($categoryObjects as $category) {
                $categories->attach($category);
            }
            $this->sortedCategories = $categories;
        }

        return $this->sortedCategories;
    }

    /**
     * @param int $groupId
     * @return ObjectStorage
     */
    private function getCategoryGroup(int $groupId): ObjectStorage
    {
        $categories = new ObjectStorage();
        $settings = $this->getSettings();

        if (false === isset($settings['fields']['categories']['groups'][$groupId]['parentUid'])) {
            return $categories;
        }

        if (false === isset($this->categoryGroups[$groupId])) {
            $parentUid = (int)$settings['fields']['categories']['groups'][$groupId]['parentUid'];
            foreach ($this->getSortedCategories() as $category) {
                if ($parentUid === $category->getParent()->getUid()) {
                    $categories->attach($category);
                }
            }
            $this->categoryGroups[$groupId] = $categories;
        }

        return $this->categoryGroups[$groupId];
    }

    /**
     * @return ObjectStorage
     */
    public function getCategoryGroup1(): ObjectStorage
    {
        return $this->getCategoryGroup(1);
    }

    /**
     * @return ObjectStorage
     */
    public function getCategoryGroup2(): ObjectStorage
    {
        return $this->getCategoryGroup(2);
    }

    /**
     * @return ObjectStorage
     */
    public function getCategoryGroup3(): ObjectStorage
    {
        return $this->getCategoryGroup(3);
    }

    /**
     * @return ObjectStorage
     */
    public function getCategoryGroup4(): ObjectStorage
    {
        return $this->getCategoryGroup(4);
    }

    /**
     * @return ObjectStorage
     */
    public function getCategoryGroup5(): ObjectStorage
    {
        return $this->getCategoryGroup(5);
    }

    /**
     * @return int
     */
    public function getGender(): int
    {
        return $this->gender;
    }

    /**
     * @return \DateTime|null
     */
    public function getBirthDate(): ?\DateTime
    {
        return $this->birthDate;
    }

    /**
     * @return string
     */
    public function getAbstract(): string
    {
        return $this->abstract;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @return string
     */
    public function getFamilyName(): string
    {
        return $this->familyName;
    }

    /**
     * @return string
     */
    public function getGivenName(): string
    {
        return $this->givenName;
    }

    /**
     * @return string
     */
    public function getHonorificPrefix(): string
    {
        return $this->honorificPrefix;
    }

    /**
     * @return string
     */
    public function getHonorificSuffix(): string
    {
        return $this->honorificSuffix;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * @return string
     */
    public function getWebsite(): string
    {
        return $this->website;
    }
}
