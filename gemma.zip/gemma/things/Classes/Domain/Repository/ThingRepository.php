<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Repository;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Earlybird\Things\Domain\Model\Dto\CategoriesConstraint;
use Earlybird\Things\Domain\Model\Dto\FindThingsConstraint;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\QueryResultInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;

class ThingRepository extends Repository
{
    /** @var array */
    protected $defaultOrderings = [
        'name' => QueryInterface::ORDER_ASCENDING,
    ];

    /**
     * @param FindThingsConstraint $constraint
     *
     * @return array|QueryResultInterface
     */
    public function findByConstraint(FindThingsConstraint $constraint)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('tx_things_domain_model_thing');
        try {
            $query = $this->createQuery();
            $queryConstraint = [];

            // Set limit
            $query->setLimit($constraint->getLimit());

            // Set offset
            $query->setOffset($constraint->getOffset());

            // Set ordering
            $orderings = $constraint->getOrderings();
            if (false === empty($orderings)) {
                $query->setOrderings($orderings);
            }

            // UID
            $uids = $constraint->getUids();
            if (false === empty($uids)) {
                $uids = GeneralUtility::intExplode(',', implode(',', array_unique($uids)));
                $queryConstraint[] = $query->in('uid', $uids);
            }

            // UUID
            $uuids = $constraint->getUuids();
            if (false === empty($uuids)) {
                $uuids = GeneralUtility::trimExplode(',', implode(',', array_unique($uuids)));
                $queryConstraint[] = $query->in('uuid', $uuids);
            }
            unset($uuids);

            // Type
            $types = $constraint->getTypes();
            if (false === empty($types)) {
                $types = GeneralUtility::trimExplode(',', implode(',', array_unique($types)));
                $queryConstraint[] = $query->in('type', $types);
            }
            unset($types);

            // Subtype
            $subtypes = $constraint->getSubtypes();
            if (false === empty($subtypes)) {
                $subtypes = GeneralUtility::trimExplode(',', implode(',', array_unique($subtypes)));
                $queryConstraint[] = $query->in('subtype', $subtypes);
            }
            unset($subtypes);

            // primaryPostalAddress.code
            $primaryPostalAddressCodes = $constraint->getPrimaryPostalAddressCodes();
            if (false === empty($primaryPostalAddressCodes)) {
                if ('NONEMPTY' === $primaryPostalAddressCodes[0]) {
                    $queryConstraint[] = $query->logicalNot($query->equals('primaryPostalAddress.code', ''));
                } else {
                    $primaryPostalAddressCodes = GeneralUtility::trimExplode(',', implode(',', array_unique($primaryPostalAddressCodes)));
                    $queryConstraint[] = $query->in('primaryPostalAddress.code', $primaryPostalAddressCodes);
                }
            }
            unset($primaryPostalAddressCodes);

            // Categories
            $categoryConstraints = [];
            foreach ($constraint->getCategories() as $categoriesConstraint) {
                /** @var CategoriesConstraint $categoriesConstraint */
                if (false === empty($categoriesConstraint->getUids())) {
                    $categorySubConstraint = [];
                    foreach ($categoriesConstraint->getUids() as $category) {
                        $categorySubConstraint[] = $query->contains('categories', $category);
                    }
                    switch ($categoriesConstraint->getConjunction()) {
                        case 'OR':
                            $categoryConstraints[] = $query->logicalOr($categorySubConstraint);
                            break;
                        case 'NOR':
                            $categoryConstraints[] = $query->logicalNot($query->logicalAnd($categorySubConstraint));
                            break;
                        case 'NAND':
                            $categoryConstraints[] = $query->logicalNot($query->logicalOr($categorySubConstraint));
                            break;
                        default: // 'AND'
                            $categoryConstraints[] = $query->logicalAnd($categorySubConstraint);
                    }
                }
            }
            if (false === empty($categoryConstraints)) {
                $queryConstraint[] = $query->logicalAnd($categoryConstraints);
            }
            $searchTerms = '%' . $queryBuilder->escapeLikeWildcards($constraint->getSearchTerms()) . '%';
            if (false === empty($searchTerms)) {
                if(strlen($searchTerms) < 6){
                    $searchTerms = substr($searchTerms, 1); 
                    $queryConstraint[] = $query->logicalOr([
                    $query->like('family_name', $searchTerms),
                    ]);
                }else{
                    $queryConstraint[] = $query->logicalOr([
                        $query->like('primaryPostalAddress.code', $searchTerms),
                        $query->like('categories.title', $searchTerms),
                        $query->like('family_name', $searchTerms),
                        $query->like('given_name', $searchTerms),
                        $query->like('title', $searchTerms),
                    ]);
                }
                
            }


            // Finally apply the constraint
            if (false === empty($queryConstraint)) {
                $query->matching(
                    $query->logicalAnd($queryConstraint)
                );
            }

            $result = $query->execute();
        } catch (\Exception $exception) {
            $result = [];
        }

        return $result;
    }
}
