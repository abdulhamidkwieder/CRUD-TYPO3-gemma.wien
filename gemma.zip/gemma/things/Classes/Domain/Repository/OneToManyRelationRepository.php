<?php
declare(strict_types=1);
namespace Earlybird\Things\Domain\Repository;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Extbase\Persistence\ObjectStorage;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\QueryResultInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;

class OneToManyRelationRepository extends Repository
{
    /**
     * @param int $uid
     * @param array $settings
     *
     * @return ObjectStorage
     */
    public function findByParent(int $uid, array $settings): ObjectStorage
    {
        $objectStorage = new ObjectStorage();
        $result = [];
        if (
            true === isset($settings['limit'])
            && 1 > (int)$settings['limit']
        ) {
            return $objectStorage;
        }

        if (true === isset($settings['types']) && true === is_array($settings['types'])) {
            $types = array_keys($settings['types']);
            foreach ($types as $type) {
                if (
                    true === isset($settings['types'][$type]['enable'])
                    && true === filter_var($settings['types'][$type]['enable'], FILTER_VALIDATE_BOOLEAN)
                ) {
                    $limit = (true === isset($settings['types'][$type]['limit'])) ? (int)$settings['types'][$type]['limit'] : 0;
                    if (1 <= $limit) {
                        $records = $this->findByParentAndType($uid, $type, $limit);
                        foreach ($records as $record) {
                            if (true === method_exists ( $record, 'getSortingForeign')) {
                                $result[$record->getSortingForeign()] = $record;
                            } else {
                                $result[] = $record;
                            }
                        }
                    }
                }
            }

            // Sort and reset keys
            ksort($result);
            $result = array_values($result);
        }

        // Apply global limit
        if (true === isset($settings['limit'])) {
            $result = array_slice($result, 0, (int)$settings['limit']);
        }

        foreach ($result as $resultObject) {
            $objectStorage->attach($resultObject);
        }
        $objectStorage->rewind();

        return $objectStorage;
    }

    /**
     * @param int $uid
     * @param int $type
     * @param int $limit
     *
     * @return QueryResultInterface|array
     */
    public function findByParentAndType(int $uid, int $type, int $limit = 99)
    {
        try {
            $query = $this->createQuery();
            $query->setLimit($limit);
            $query->setOrderings(['sorting_foreign' => QueryInterface::ORDER_ASCENDING]);

            $queryConstraint = [
                $query->equals('uid_foreign', $uid),
                $query->equals('type', $type),
            ];
            $query->matching(
                $query->logicalAnd($queryConstraint)
            );

            $result = $query->execute();
        } catch (\Exception $exception) {
            $result = [];
        }

        return $result;
    }
}
