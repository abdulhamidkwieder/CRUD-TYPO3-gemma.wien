<?php
declare(strict_types=1);
namespace Earlybird\Things\Service;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Configuration\ConfigurationManager;
use TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface;
use TYPO3\CMS\Extbase\Object\ObjectManager;

class SettingsService {
    /** @var string */
    protected $extensionName = 'things';

    /** @var ObjectManager */
    protected $objectManager = null;

    /** @var array */
    protected $tsSettings = [];

    /**
     * @return array
     */
    public function getTsSettings(): array
    {
        if (true === empty($this->tsSettings)) {
            $this->objectManager = (null === $this->objectManager) ? GeneralUtility::makeInstance(ObjectManager::class): $this->objectManager;
            $configurationManager = $this->objectManager->get(ConfigurationManager::class);
            try {
                $this->tsSettings = $configurationManager->getConfiguration(
                    ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK,
                    $this->extensionName,
                    ''
                );
            } catch (\Exception $exception) {
                // :(
            }
        }

        return $this->tsSettings;
    }

    /**
     * Get the storagePid from TS settings.
     *
     * If $entity is set, we first try to get the storagePid from
     * `plugin.tx_things.persistence.classes.{entityClassPath}.newRecordStoragePid`
     *
     * Next we try `plugin.tx_things.persistence.storagePid`
     *
     * If we can't find any valid storagePid it's '0'.
     *
     * @return int
     */
    public function getStoragePid($entity = null): int
    {
        $this->getTsSettings();
        $pid = 0;

        if (
            false === empty($entity)
            && true === isset($this->tsSettings['persistence']['classes'][$entity]['newRecordStoragePid'])
        ) {
            $pid = (int)$this->tsSettings['persistence']['classes'][$entity]['newRecordStoragePid'];
        }
        if (
            true === empty($pid)
            && true === isset($this->tsSettings['persistence']['storagePid'])
        ) {
            $pid = (int)$this->tsSettings['persistence']['storagePid'];
        }

        return $pid;
    }
}