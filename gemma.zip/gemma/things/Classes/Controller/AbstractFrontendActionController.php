<?php
declare(strict_types=1);
namespace Earlybird\Things\Controller;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController as TYPO3ActionController;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

abstract class AbstractFrontendActionController extends TYPO3ActionController
{
    /**
     * Global Initialize Action (executed before any Action in the Controller)
     *
     * @return void
     */
    public function initializeAction(): void
    {
        $this->view->assignMultiple([
            'lll' => 'LLL' . ':EXT:things/Resources/Private/Language/locallang.xlf:',
        ]);
    }

    /**
     * Wrapper call to static LocalizationUtility
     *
     * @param string $id Translation Key compatible to TYPO3 Flow
     * @param string $extensionName UpperCamelCased extension key (for example BlogExample)
     * @param array $arguments Arguments to be replaced in the resulting string
     *
     * @return string|null
     */
    protected function translate($id, $extensionName = null, $arguments = null): ?string
    {
        if (null === $extensionName) {
            $extensionName = 'things';
        }

        return LocalizationUtility::translate($id, $extensionName, $arguments);
    }
}