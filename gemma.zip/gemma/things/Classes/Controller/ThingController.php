<?php
declare(strict_types=1);
namespace Earlybird\Things\Controller;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Earlybird\Things\Domain\Model\Dto\FindThingsConstraint;
use Earlybird\Things\Domain\Model\Thing;
use Earlybird\Things\Domain\Repository\ThingRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class ThingController extends AbstractFrontendActionController
{
    /** @var ThingRepository */
    protected $thingRepository = null;

    /**
     * Inject ThingRepository
     *
     * @param ThingRepository $thingRepository
     * @return void
     */
    public function injectThingRepository(ThingRepository $thingRepository): void
    {
        $this->thingRepository = $thingRepository;
    }

    /**
     * Global Initialize Action (executed before any Action in the Controller)
     *
     * @return void
     */
    public function initializeAction(): void
    {
    }

    /**
     * Show Action
     *
     * @return void
     */
    public function showAction(): void
    {
        $thing = null;

        $uuid = null;
        if (true === isset($_GET['tx_things']['uuid'])) {
            $uuid = trim((string)$_GET['tx_things']['uuid']);
        }

        // Fetch the record
        if (false === empty($uuid)) {
            $constraint = $this->getConstraintFromSettings();
            $constraint->setUuids([$uuid]);
            $thing = $this->thingRepository->findByConstraint($constraint);
            if (
                true === isset($thing[0])
                && true === is_a($thing[0], Thing::class)
            ) {
                $thing = $thing[0];
            }
        }

        // Error handling
        if (false === is_a($thing, Thing::class)) {
            if (
                true === isset($this->settings['errorHandling']['mode'])
                && 'ignoreEmptyUuid' === (string)$this->settings['errorHandling']['mode']
                && null === $uuid
            ) {
                // Do *not* call the error handler if error handling mode is set
                // to 'ignoreEmptyUuid' and no UUID is provided
            } else {
                $handler = 'pageNotFoundHandler';
                if (
                    true === isset($this->settings['errorHandling']['handler'])
                    && false === empty($this->settings['errorHandling']['handler'])
                ) {
                    $handler = (string)$this->settings['errorHandling']['handler'];
                }
                $this->handleNotFoundError($handler, (string)$uuid);
            }
        }

        $this->view->assignMultiple([
            'settings' => $this->settings,
            'thing' => $thing,
        ]);
    }

    /**
     * @param string $handler
     * @param string $uuid
     */
    public function handleNotFoundError(string $handler, string $uuid): void
    {
        $uuid = (true === empty($uuid)) ? '[null]' : $uuid;
        switch ($handler) {
            case 'pageNotFoundHandler':
                $GLOBALS['TSFE']->pageNotFoundAndExit('Entity UUID ' . $uuid . ' not found.');
                break;
        }
    }

    /**
     * List Action
     *
     * @return void
     */
    public function listAction(): void
    {
        if (
            true === isset($_GET['tx_things']['uuid'])
            && false === empty($_GET['tx_things']['uuid'])
        ) {
            // Do not render list if a detail view is requested by an UUID
            return;
        }

        $constraint = $this->getConstraintFromSettings(); 
        
        if (false === is_null(\TYPO3\CMS\Core\Utility\GeneralUtility::_GET('q'))) {
            $constraint->setSearchTerms((string)\TYPO3\CMS\Core\Utility\GeneralUtility::_GET('q'));
        }

        $things = $this->thingRepository->findByConstraint($constraint);


        $this->view->assignMultiple([
            'settings' => $this->settings,
            'constraint' => $constraint,
            'things' => $things,
        ]);
    }

    /**
     * @return FindThingsConstraint
     */
    private function getConstraintFromSettings(): FindThingsConstraint
    {
        $constraint = $this->objectManager->get(FindThingsConstraint::class);

        if (
            true === isset($this->settings['constraint']['orderings'])
            && true === is_array($this->settings['constraint']['orderings'])
        ) {
            $constraint->setOrderings($this->settings['constraint']['orderings']);
        }

        if (
            true === isset($this->settings['constraint']['limit'])
            && '' !== $this->settings['constraint']['limit']
            && null !== $this->settings['constraint']['limit']
            && 0 <= (int)$this->settings['constraint']['limit']
        ) {
            $constraint->setLimit((int)$this->settings['constraint']['limit']);
        }

        if (true === isset($this->settings['constraint']['offset'])) {
            $constraint->setOffset((int)$this->settings['constraint']['offset']);
        }

        if (true === isset($this->settings['constraint']['uids'])) {
            $constraint->setUids(GeneralUtility::intExplode(',', (string)$this->settings['constraint']['uids'], true));
        }

        if (true === isset($this->settings['constraint']['uuids'])) {
            $constraint->setUuids(GeneralUtility::trimExplode(',', (string)$this->settings['constraint']['uuids'], true));
        }

        if (true === isset($this->settings['constraint']['types'])) {
            $constraint->setTypes(GeneralUtility::trimExplode(',', (string)$this->settings['constraint']['types'], true));
        }

        if (true === isset($this->settings['constraint']['subtypes'])) {
            $constraint->setSubtypes(GeneralUtility::trimExplode(',', (string)$this->settings['constraint']['subtypes'], true));
        }

        if (
            true === isset($this->settings['constraint']['categories'])
            && true === is_array($this->settings['constraint']['categories'])
        ) {
            $constraint->setCategories($this->settings['constraint']['categories']);
        }

        if (true === isset($this->settings['constraint']['primaryPostalAddress']['codes'])) {
            $constraint->setPrimaryPostalAddressCodes(GeneralUtility::trimExplode(',', (string)$this->settings['constraint']['primaryPostalAddress']['codes'], true));
        }

        return $constraint;
    }
}
