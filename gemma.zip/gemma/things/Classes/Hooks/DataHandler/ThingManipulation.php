<?php
declare(strict_types=1);
namespace Earlybird\Things\Hooks\DataHandler;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Earlybird\Things\Utility\AlgorithmsUtility;
use TYPO3\CMS\Backend\Utility\BackendUtility;
use TYPO3\CMS\Core\DataHandling\DataHandler;

class ThingManipulation
{
    /**
     * @var string
     */
    protected $tableName = 'tx_things_domain_model_thing';

    /**
     * This method is called by processDatamapClass hook before a record is saved in the BE.
     *
     * It Looks for changes to tx_things_domain_model_thing records and
     * applies needed additions and/or changes.
     *
     * @param array         $fieldArray
     * @param string        $table
     * @param int           $recordUid
     * @param DataHandler   $parentObject
     *
     * @return void
     */
    public function processDatamap_preProcessFieldArray(&$fieldArray, $table, $recordUid, DataHandler &$parentObject): void
    {
        if ($this->tableName === $table) {
            // Do not process when hiding an item
            if (count($fieldArray) === 1 && true === isset($fieldArray['hidden'])) {
                return;
            }

            $row = BackendUtility::getRecord($table, $recordUid);
            $tsconfig = BackendUtility::getPagesTSconfig($row['pid']);

            // Set 'birth_date' to '1970-01-01' if it's an empty string as Form Engine/JS will truncate '1970-01-01'.
            if (
                true === isset($fieldArray['birth_date'])
                && (
                    '' === $fieldArray['birth_date']
                    || '1970-01-01T' === substr($fieldArray['birth_date'], 0, 11)
                )
            ) {
                $fieldArray['birth_date'] = '1970-01-01T00:00:01Z';
            }

            // Generate an UUID on create or if it's missing
            if (
                'NEW' === substr((string)$recordUid, 0, 3)
                || (
                    true === isset($fieldArray['uuid'])
                    && true === empty($fieldArray['uuid'])
                )
                || true === empty($row['uuid'])
            ) {
                $fieldArray['uuid'] = AlgorithmsUtility::generateUUID();
            }

            // Alter UUID for translation records
            if (
                true === isset($fieldArray['uuid'])
                && true === isset($fieldArray['sys_language_uid'])
                && 1 <= (int)$fieldArray['sys_language_uid']
            ) {
                $fieldArray['uuid'] = $fieldArray['uuid'] . '-' . str_pad((string)$fieldArray['sys_language_uid'], 2, '0', STR_PAD_LEFT);
            }
            if (
                true === isset($fieldArray['uuid'])
                && 1 <= (int)$row['sys_language_uid']
            ) {
                $fieldArray['uuid'] = $fieldArray['uuid'] . '-' . str_pad((string)$row['sys_language_uid'], 2, '0', STR_PAD_LEFT);
            }

            // Generate 'name' field when saving a thing of type 'Person'
            if (
                'Person' === $fieldArray['type']
                || (
                    true === isset($tsconfig['TCAdefaults.']['tx_things_domain_model_thing.']['type'])
                    && 'Person' === $tsconfig['TCAdefaults.']['tx_things_domain_model_thing.']['type']
                )
            ) {
                $name = '';
                if (
                    false === isset($fieldArray['given_name'])
                    && false === isset($fieldArray['family_name'])
                    && true === empty($row['given_name'])
                    && true === empty($row['family_name'])
                ) {
                    // Copy 'name' to 'given_name' when switching from non-person to 'Person'
                    $fieldArray['given_name'] = $fieldArray['name'];
                    $name = $fieldArray['name'];
                } else {
                    // Generate new 'name' value
                    if (true === isset($fieldArray['family_name'])) {
                        $name .= (false === empty($fieldArray['family_name'])) ? $fieldArray['family_name'] : '?';
                    } else {
                        $name .= $row['family_name'];
                    }
                    $name .= ', ';
                    if (true === isset($fieldArray['given_name'])) {
                        $name .= (false === empty($fieldArray['given_name'])) ? $fieldArray['given_name'] : '?';
                    } else {
                        $name .= $row['given_name'];
                    }
                }
                $fieldArray['name'] = $name;
            }
        }
    }

    /**
     * This method is called by processDatamapClass hook after a record is saved in the BE.
     *
     * @param string        $status
     * @param string        $table
     * @param int           $recordUid
     * @param array         $fields
     * @param DataHandler   $parentObject
     *
     * @return void
     */
    public function processDatamap_postProcessFieldArray($status, $table, $recordUid, array &$fields, DataHandler $parentObject): void
    {
        // Save new record with given type if stated by Page TSconfig also if field is hidden in BE.
        // To e.g. preset the type with type 'Person' use
        //      # Hide type field
        //      TCEFORM.tx_things_domain_model_thing.type.disabled = 1
        //      # Set default value
        //      TCAdefaults.tx_things_domain_model_thing.type = Person
        if ('new' === $status && $table === $this->tableName) {
            $tsconfig = BackendUtility::getPagesTSconfig($fields['pid']);
            if (
                true === isset($tsconfig['TCAdefaults.']['tx_things_domain_model_thing.']['type'])
                && false === empty($tsconfig['TCAdefaults.']['tx_things_domain_model_thing.']['type'])
            ) {
                $fields['type'] = (string)$tsconfig['TCAdefaults.']['tx_things_domain_model_thing.']['type'];
            }
        }
    }
}
