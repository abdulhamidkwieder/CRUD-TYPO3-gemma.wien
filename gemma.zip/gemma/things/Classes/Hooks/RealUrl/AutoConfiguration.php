<?php
declare(strict_types=1);
namespace Earlybird\Things\Hooks\RealUrl;

/*
 * (c) 2018 Earlybird TYPO3 Team <typo3@earlybird.at>
 *
 * This script is part of Earlybird's TYPO3 project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License, either version 3
 * of the License, or (at your option) any later version.
 *
 * The TYPO3 project - inspiring people to share!
 */

use TYPO3\CMS\Core\Utility\ArrayUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class AutoConfiguration
{
    /**
     * Generates additional RealURL configuration and merges it with existing configuration
     *
     * @param  array $params Default configuration
     *
     * @return array Updated configuration
     */
    public function addConfig($params)
    {
        $config = $params['config'];

        // Read extension configuration
        $extConf = [];
        if (true === isset($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['things'])) {
            $extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['things']);
        }

        $extendedConfig = [
            'postVarSets' => [
                '_DEFAULT' => [
                    // Detail view
                    'uuid' => [
                        ['GETvar' => 'tx_things[uuid]'],
                    ],
                ],
            ],
            'fixedPostVars' => [
                # Pagination (List view)
                'tx_things_list' => [
                    ['GETvar' => 'tx_things_list[@widget_0][currentPage]'],
                ],
            ],
        ];

        // Page IDs using EXT:things list view
        if (true === isset($extConf['thingsListPid'])) {
            foreach (GeneralUtility::intExplode(',', $extConf['thingsListPid'], true) as $pid) {
                if (0 < $pid) {
                    $extendedConfig['fixedPostVars'][$pid] = 'tx_things_list';
                }
            }
        }

        // Add our config
        ArrayUtility::mergeRecursiveWithOverrule($config, $extendedConfig);

        return $config;
    }
}