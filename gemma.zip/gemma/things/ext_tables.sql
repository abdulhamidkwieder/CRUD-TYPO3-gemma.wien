-- noinspection SqlNoDataSourceInspectionForFile

--
-- Table structure for table 'tx_things_domain_model_thing'
--
CREATE TABLE tx_things_domain_model_thing (
  uid int(11) NOT NULL auto_increment,
  uuid char(39) DEFAULT '' NOT NULL,
  identifier varchar(64) DEFAULT '' NOT NULL,
  pid int(11) DEFAULT '0' NOT NULL,

  type varchar(64) DEFAULT '' NOT NULL,
  subtype varchar(64) DEFAULT '' NOT NULL,
  name varchar(255) DEFAULT '' NOT NULL,
  abstract varchar(255) DEFAULT '' NOT NULL,
  description text,
  notes varchar(255) DEFAULT '' NOT NULL,

  family_name varchar(64) DEFAULT '' NOT NULL,
  given_name varchar(64) DEFAULT '' NOT NULL,
  honorific_prefix varchar(64) DEFAULT '' NOT NULL,
  honorific_suffix varchar(64) DEFAULT '' NOT NULL,
  title varchar(128) DEFAULT '' NOT NULL,
  gender smallint(5) unsigned DEFAULT '0' NOT NULL,
  birth_date date DEFAULT NULL,

  website varchar(1024) DEFAULT '' NOT NULL,
  postal_addresses int(11) unsigned DEFAULT '0' NOT NULL,
  email_addresses int(11) unsigned DEFAULT '0' NOT NULL,
  phone_numbers int(11) unsigned DEFAULT '0' NOT NULL,
  fax_numbers int(11) unsigned DEFAULT '0' NOT NULL,
  primary_postal_address int(11) unsigned DEFAULT '0' NOT NULL,
  primary_email_address int(11) unsigned DEFAULT '0' NOT NULL,
  primary_phone_number int(11) unsigned DEFAULT '0' NOT NULL,

  deprecated smallint(5) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
  hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  categories int(11) unsigned DEFAULT '0' NOT NULL,

  t3_origuid int(11) DEFAULT '0' NOT NULL,
  sys_language_uid int(11) DEFAULT '0' NOT NULL,
  l10n_parent int(11) DEFAULT '0' NOT NULL,
  l10n_diffsource mediumblob,
  l10n_source int(11) DEFAULT '0' NOT NULL,
  l10n_state text,

  PRIMARY KEY (uid),
  UNIQUE KEY uuid (uuid),
  KEY parent (pid,deleted),
  KEY language (l10n_parent,sys_language_uid)
);

--
-- Table structure for table 'tx_things_domain_model_postaladdress'
--
CREATE TABLE tx_things_domain_model_postaladdress (
  uid int(11) NOT NULL auto_increment,
  pid int(11) DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

  type varchar(64) DEFAULT '' NOT NULL,
  address varchar(512) DEFAULT '' NOT NULL,
  street varchar(255) DEFAULT '' NOT NULL,
  extended varchar(64) DEFAULT '' NOT NULL,
  code varchar(16) DEFAULT '' NOT NULL,
  locality varchar(64) DEFAULT '' NOT NULL,
  region varchar(64) DEFAULT '' NOT NULL,
  country varchar(64) DEFAULT '' NOT NULL,
  latitude double NOT NULL,
  longitude double NOT NULL,
  notes varchar(255) DEFAULT '' NOT NULL,

  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
  hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

  PRIMARY KEY (uid),
  KEY parent (pid,deleted)
);

--
-- Table structure for table 'tx_things_domain_model_emailaddress'
--
CREATE TABLE tx_things_domain_model_emailaddress (
  uid int(11) NOT NULL auto_increment,
  pid int(11) DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

  type varchar(64) DEFAULT '' NOT NULL,
  email varchar(255) DEFAULT '' NOT NULL,
  notes varchar(255) DEFAULT '' NOT NULL,

  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
  hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

  PRIMARY KEY (uid),
  KEY parent (pid,deleted)
);

--
-- Table structure for table 'tx_things_domain_model_phonenumber'
--
CREATE TABLE tx_things_domain_model_phonenumber (
  uid int(11) NOT NULL auto_increment,
  pid int(11) DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

  type varchar(64) DEFAULT '' NOT NULL,
  number varchar(64) DEFAULT '' NOT NULL,
  notes varchar(255) DEFAULT '' NOT NULL,

  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
  hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

  PRIMARY KEY (uid),
  KEY parent (pid,deleted)
);

--
-- Table structure for table 'tx_things_domain_model_faxnumber'
--
CREATE TABLE tx_things_domain_model_faxnumber (
  uid int(11) NOT NULL auto_increment,
  pid int(11) DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

  type varchar(64) DEFAULT '' NOT NULL,
  number varchar(64) DEFAULT '' NOT NULL,
  notes varchar(255) DEFAULT '' NOT NULL,

  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
  hidden smallint(5) unsigned DEFAULT '0' NOT NULL,

  PRIMARY KEY (uid),
  KEY parent (pid,deleted)
);
