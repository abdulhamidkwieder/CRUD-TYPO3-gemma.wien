<?php
/** @var string $_EXTKEY */
defined('TYPO3_MODE') or die();

call_user_func(
    /**
     * @param string $extKey
     */
    function ($extKey)
    {
        if ('BE' === TYPO3_MODE) {
            /**
             * Add Page TSConfig
             */
            \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
                '<INCLUDE_TYPOSCRIPT: source="FILE:EXT:' . $extKey . '/Configuration/TsConfig/Page.tsconfig">'
            );

            /** @var \TYPO3\CMS\Core\Imaging\IconRegistry $iconRegistry */
            $iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);

            // Register SVG icons
            $icons = [
                // PageTree icons
                'apps-pagetree-folder-contains-things' => 'Apps/apps-pagetree-folder-contains-things.svg',
            ];
            foreach ($icons as $identifier => $path) {
                if (false === \TYPO3\CMS\Core\Utility\StringUtility::beginsWith($path, 'EXT:')) {
                    $path = 'EXT:things/Resources/Public/Icons/' . $path;
                }
                $iconRegistry->registerIcon(
                    $identifier,
                    \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
                    ['source' => $path]
                );
            }
            // Register FontAwesome icons
            $faIcons = [
                // Plugins
                'ext-things-plugin-detail' => 'info-circle',
                'ext-things-plugin-list' => 'list-alt',
                // Entities
                'mimetypes-ext-things-thing' => 'asterisk',
                'mimetypes-ext-things-action' => 'cogs',
                'mimetypes-ext-things-creativeWork' => 'picture-o',
                'mimetypes-ext-things-event' => 'calendar',
                'mimetypes-ext-things-intangible' => 'archive',
                'mimetypes-ext-things-medicalEntity' => 'medkit',
                'mimetypes-ext-things-organization' => 'building-o',
                'mimetypes-ext-things-person' => 'user',
                'mimetypes-ext-things-place' => 'map-marker',
                'mimetypes-ext-things-product' => 'shopping-cart',
                'mimetypes-ext-things-person-female' => 'venus',
                'mimetypes-ext-things-person-male' => 'mars',
                'mimetypes-ext-things-email' => 'envelope',
                'mimetypes-ext-things-phone' => 'phone',
                'mimetypes-ext-things-fax' => 'fax',
                'mimetypes-ext-things-mobile' => 'mobile',
            ];
            foreach ($faIcons as $identifier => $iconName) {
                $iconRegistry->registerIcon(
                    $identifier,
                    \TYPO3\CMS\Core\Imaging\IconProvider\FontawesomeIconProvider::class,
                    ['name' => ('fa-' === substr($iconName, 0, 3)) ? substr($iconName, 3) : $iconName]
                );
            }

            /**
             * Hooks
             */
            // DataHandler: Save records
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processDatamapClass']['things_thing'] =
                \Earlybird\Things\Hooks\DataHandler\ThingManipulation::class;
        }

        /**
         * Add Default TypoScript
         */
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScriptSetup(
            '<INCLUDE_TYPOSCRIPT: source="FILE:EXT:' . $extKey . '/Configuration/TypoScript/setup.txt">'
        );

        /**
         * RealUrl AutoConfiguration
         */
        if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('realurl')) {
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['ext/realurl/class.tx_realurl_autoconfgen.php']['extensionConfiguration']['things'] =
                \Earlybird\Things\Hooks\RealUrl\AutoConfiguration::class . '->addConfig';
        }

        /**
         * Configure Plugin 'Detail' (plugin.tx_things_detail)
         */
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Earlybird.Things',
            'Detail',
            // Allowed actions
            [
                'Thing' => 'show',
            ],
            // Non-cacheable actions
            []
        );

        /**
         * Configure Plugin 'List' (plugin.tx_things_list)
         */
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Earlybird.Things',
            'List',
            // Allowed actions
            [
                'Thing' => 'list',
            ],
            // Non-cacheable actions
            [
                'Thing' => 'list',
            ]
        );
    },
    $_EXTKEY
);
