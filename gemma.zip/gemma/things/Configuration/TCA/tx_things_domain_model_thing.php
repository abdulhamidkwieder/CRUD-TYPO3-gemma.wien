<?php

$LLC = 'LLL' . ':EXT:lang/Resources/Private/Language/';
$LLB = 'LLL' . ':EXT:things/Resources/Private/Language/locallang.xlf:';
$LLL = $LLB . 'entities.thing.';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::makeCategorizable(
    'things',
    'tx_things_domain_model_thing'
);

$tcaConfig = [
    'ctrl' => [
        'title' => $LLL . 'label',
        'label' => 'name',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'delete' => 'deleted',
        'default_sortby' => 'name ASC, uid ASC',
        'enablecolumns' => [
            'disabled' => 'hidden',
        ],
        'languageField' => 'sys_language_uid',
        'origUid' => 't3_origuid',
        'searchFields' => 'type, subtype, uuid, identifier, name, abstract, description, title, website',
        'translationSource' => 'l10n_source',
        'transOrigDiffSourceField' => 'l10n_diffsource',
        'transOrigPointerField' => 'l10n_parent',
        'type' => 'type',
        'typeicon_column' => 'type',
        'typeicon_classes' => [
            'default'       => 'mimetypes-ext-things-thing',
            'Action'        => 'mimetypes-ext-things-action',
            'CreativeWork'  => 'mimetypes-ext-things-creativeWork',
            'Event'         => 'mimetypes-ext-things-event',
            'Intangible'    => 'mimetypes-ext-things-intangible',
            'MedicalEntity' => 'mimetypes-ext-things-medicalEntity',
            'Organization'  => 'mimetypes-ext-things-organization',
            'Person'        => 'mimetypes-ext-things-person',
            'Place'         => 'mimetypes-ext-things-place',
            'Product'       => 'mimetypes-ext-things-product',
        ],
        'rootLevel' => 0, // Can only exist in the page tree
    ],
    'interface' => [
        'showRecordFieldList' => 'type, subtype, identifier, uuid, hidden, name, abstract, website',
    ],
    'palettes' => [
        '10' => ['showitem' => 'type, subtype, identifier, uuid'],
        '20' => ['showitem' => 'name'],
        '30' => ['showitem' => 'given_name, family_name, --linebreak--, honorific_prefix, honorific_suffix, --linebreak--, title, --linebreak--, gender, birth_date'],
    ],
    'types' => [
        // Default type ('Thing')
        '0' => [
            'showitem' => '
                --palette--;;10,
                --palette--;;20,
                --palette--;;30,
                deprecated,
                --div--;' . $LLL . 'tabs.description,
                    abstract,
                    description,
                --div--;' . $LLL . 'tabs.contact,
                    website,
                    postal_addresses,
                    primary_postal_address,
                    email_addresses,
                    primary_email_address,
                    phone_numbers,
                    primary_phone_number,
                    fax_numbers,
                --div--;'. $LLC . 'locallang_tca.xlf:sys_category.categories,
                    categories,
                --div--;' . $LLL . 'tabs.extra,
                    sys_language_uid,
                    notes,
            ',
        ],
    ],
    'columns' => [
        'type' => [
            'exclude' => true,
            'label' => $LLL . 'type.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [],
            ],
        ],
        'subtype' => [
            'exclude' => true,
            'label' => $LLL . 'subtype.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLL . 'subtype.options.default', '', ''],
                ],
            ],
        ],
        'identifier' => [
            'exclude' => true,
            'label' => $LLL . 'identifier.label',
            'l10n_mode' => 'exclude',
            'l10n_display' => 'defaultAsReadonly',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'max' => 64,
                'eval' => 'trim',
                'placeholder' => $LLL . 'identifier.placeholder',
            ],
        ],
        'name' => [
            'exclude' => true,
            'label' => $LLL . 'name.label',
            'l10n_mode' => 'exclude',
            'l10n_display' => 'defaultAsReadonly',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'name.placeholder',
            ],
        ],
        'abstract' => [
            'exclude' => true,
            'label' => $LLL . 'abstract.label',
            'config' => [
                'type' => 'text',
                'cols' => 80,
                'rows' => 5,
                'max' => 255,
                'eval' => 'trim',
                'behaviour' => [
                    'allowLanguageSynchronization' => true,
                ],
            ],
        ],
        'description' => [
            'exclude' => true,
            'label' => $LLL . 'description.label',
            'config' => [
                'type' => 'text',
                'cols' => 80,
                'rows' => 5,
                'enableRichtext' => true,
                'richtextConfiguration' => 'default',
                'eval' => 'trim',
                'behaviour' => [
                    'allowLanguageSynchronization' => true,
                ],
            ],
        ],
        'family_name' => [
            'exclude' => true,
            'label' => $LLL . 'family_name.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'family_name.placeholder',
            ],
        ],
        'given_name' => [
            'exclude' => true,
            'label' => $LLL . 'given_name.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'given_name.placeholder',
            ],
        ],
        'honorific_prefix' => [
            'exclude' => true,
            'label' => $LLL . 'honorific_prefix.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim',
                'placeholder' => $LLL . 'honorific_prefix.placeholder',
            ],
        ],
        'honorific_suffix' => [
            'exclude' => true,
            'label' => $LLL . 'honorific_suffix.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim',
                'placeholder' => $LLL . 'honorific_suffix.placeholder',
            ],
        ],
        'title' => [
            'exclude' => true,
            'label' => $LLL . 'title.label',
            'displayCond' => 'FIELD:type:=:Person',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 128,
                'eval' => 'trim',
                'placeholder' => $LLL . 'title.placeholder',
                'behaviour' => [
                    'allowLanguageSynchronization' => true,
                ],
            ],
        ],
        'deprecated' => [
            'exclude' => true,
            'label' => $LLL . 'deprecated.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLL . 'deprecated.options.1', 1, 'mimetypes-ext-things-person'],
                    [$LLL . 'deprecated.options.2', 0, 'mimetypes-ext-things-person'],
                ],
            ],
        ],
        'gender' => [
            'exclude' => true,
            'label' => $LLL . 'gender.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['', 0, ''],
                    [$LLL . 'gender.options.1', 1, 'mimetypes-ext-things-person-female'],
                    [$LLL . 'gender.options.2', 2, 'mimetypes-ext-things-person-male'],
                ],
            ],
        ],
        'birth_date' => [
            'exclude' => true,
            'label' => $LLL . 'birth_date.label',
            'displayCond' => 'FIELD:type:=:Person',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'dbType' => 'date',
                'eval' => 'date,null',
            ],
        ],
        'website' => [
            'exclude' => true,
            'label' => $LLL . 'website.label',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 1024,
                'eval' => 'trim',
                'placeholder' => $LLL . 'website.placeholder',
                'behaviour' => [
                    'allowLanguageSynchronization' => true,
                ],
            ],
        ],
        'postal_addresses' => [
            'exclude' => true,
            'label' => $LLL . 'postal_addresses.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_things_domain_model_postaladdress',
                'foreign_field' => 'uid_foreign',
                'foreign_sortby' => 'sorting_foreign',
                'maxitems' => 20,
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'useSortable' => 1,
                ],
            ],
        ],
        'primary_postal_address' => [
            'exclude' => true,
            'label' => $LLL . 'primary_postal_address.label',
            'l10n_mode' => 'exclude',
            'displayCond' => 'FIELD:postal_addresses:>:0',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLB . 'globals.options.undefined', 0],
                ],
                'foreign_table' => 'tx_things_domain_model_postaladdress',
                'foreign_table_where' => 'AND tx_things_domain_model_postaladdress.uid_foreign=###THIS_UID### ORDER BY tx_things_domain_model_postaladdress.sorting_foreign',
            ],
        ],
        'email_addresses' => [
            'exclude' => true,
            'label' => $LLL . 'email_addresses.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_things_domain_model_emailaddress',
                'foreign_field' => 'uid_foreign',
                'foreign_sortby' => 'sorting_foreign',
                'maxitems' => 20,
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'useSortable' => 1,
                ],
            ],
        ],
        'primary_email_address' => [
            'exclude' => true,
            'label' => $LLL . 'primary_email_address.label',
            'l10n_mode' => 'exclude',
            'displayCond' => 'FIELD:email_addresses:>:0',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLB . 'globals.options.undefined', 0],
                ],
                'foreign_table' => 'tx_things_domain_model_emailaddress',
                'foreign_table_where' => 'AND tx_things_domain_model_emailaddress.uid_foreign=###THIS_UID### ORDER BY tx_things_domain_model_emailaddress.sorting_foreign',
            ],
        ],
        'phone_numbers' => [
            'exclude' => true,
            'label' => $LLL . 'phone_numbers.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_things_domain_model_phonenumber',
                'foreign_field' => 'uid_foreign',
                'foreign_sortby' => 'sorting_foreign',
                'maxitems' => 20,
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'useSortable' => 1,
                ],
            ],
        ],
        'primary_phone_number' => [
            'exclude' => true,
            'label' => $LLL . 'primary_phone_number.label',
            'l10n_mode' => 'exclude',
            'displayCond' => 'FIELD:phone_numbers:>:0',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLB . 'globals.options.undefined', 0],
                ],
                'foreign_table' => 'tx_things_domain_model_phonenumber',
                'foreign_table_where' => 'AND tx_things_domain_model_phonenumber.uid_foreign=###THIS_UID### ORDER BY tx_things_domain_model_phonenumber.sorting_foreign',
            ],
        ],
        'fax_numbers' => [
            'exclude' => true,
            'label' => $LLL . 'fax_numbers.label',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_things_domain_model_faxnumber',
                'foreign_field' => 'uid_foreign',
                'foreign_sortby' => 'sorting_foreign',
                'maxitems' => 20,
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'useSortable' => 1,
                ],
            ],
        ],
        'notes' => [
            'exclude' => true,
            'label' => $LLB . 'globals.notes.label',
            'config' => [
                'type' => 'text',
                'cols' => 80,
                'rows' => 2,
                'max' => 255,
                'eval' => 'trim',
            ],
        ],

        // TYPO3 internal fields
        // Note: The order in which you define fields affects various sections in the BE
        //       (e.g. 'Set fields' in list view). Thus move more important fields up
        //       and less often used fields down :)
        'hidden' => [
            'exclude' => true,
            'label' => $LLC . 'locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => $LLC . 'locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'sys_language_uid' => [
            'exclude' => true,
            'label'  => $LLC . 'locallang_general.xml:LGL.language',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'readOnly' => true,
                'foreign_table' => 'sys_language',
                'foreign_table_where' => 'ORDER BY sys_language.title',
                'items' => [
                    [$LLC . 'locallang_general.xml:LGL.allLanguages', -1],
                    [$LLC . 'locallang_general.xml:LGL.default_value', 0]
                ],
                'default' => 0,
            ]
        ],
        'l10n_parent' => [
            'displayCond' => 'FIELD:sys_language_uid:>:0',
            'exclude' => true,
            'label' => $LLC . 'locallang_general.xml:LGL.l18n_parent',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['', 0],
                ],
                'foreign_table' => 'tx_things_domain_model_thing',
                'foreign_table_where' => 'AND tx_things_domain_model_thing.pid=###CURRENT_PID### AND tx_things_domain_model_thing.sys_language_uid IN (-1,0)',
                'default' => 0,
            ]
        ],
        'l10n_diffsource' => [
            'config' => [
                'type' => 'passthrough',
                'default' => '',
            ]
        ],
        // UUID (to hide uid in FE)
        'uuid' => [
            'exclude' => false,
            'label' => $LLB . 'globals.uuid.label',
            'displayCond' => 'FIELD:uid:>:0',
            'l10n_mode' => 'exclude',
            'config' => [
                'type' => 'input',
                'readOnly' => true,
            ],
        ],
    ],
];

$types = [
    [
        'id' => '',
        'label' => $LLL . 'type.options.Thing',
        'icon' => 'mimetypes-ext-things-thing'
    ],
    [
        'id' => 'Action',
        'label' => $LLL . 'type.options.Action',
        'icon' => 'mimetypes-ext-things-action'
    ],
    [
        'id' => 'CreativeWork',
        'label' => $LLL . 'type.options.CreativeWork',
        'icon' => 'mimetypes-ext-things-creativeWork'
    ],
    [
        'id' => 'Event',
        'label' => $LLL . 'type.options.Event',
        'icon' => 'mimetypes-ext-things-event'
    ],
    [
        'id' => 'Intangible',
        'label' => $LLL . 'type.options.Intangible',
        'icon' => 'mimetypes-ext-things-intangible'
    ],
    [
        'id' => 'MedicalEntity',
        'label' => $LLL . 'type.options.MedicalEntity',
        'icon' => 'mimetypes-ext-things-medicalEntity'
    ],
    [
        'id' => 'Organization',
        'label' => $LLL . 'type.options.Organization',
        'icon' => 'mimetypes-ext-things-organization'
    ],
    [
        'id' => 'Person',
        'label' => $LLL . 'type.options.Person',
        'icon' => 'mimetypes-ext-things-person'
    ],
    [
        'id' => 'Place',
        'label' => $LLL . 'type.options.Place',
        'icon' => 'mimetypes-ext-things-place'
    ],
    [
        'id' => 'Product',
        'label' => $LLL . 'type.options.Product',
        'icon' => 'mimetypes-ext-things-product'
    ],
];

foreach ($types as $type) {
    $typeId = $type['id'];
    // Add as type option
    $tcaConfig['columns']['type']['config']['items'][] = [
        0 => $type['label'],
        1 => $type['id'],
        2 => $type['icon'],
    ];
    // Add to $GLOBALS['TCA']['tx_things_domain_model_thing']['types'] to enable type selectors in TCEFORM.tx_things_domain_model_thing
    $tcaConfig['types'][$typeId] = $tcaConfig['types']['0'];
}

$tcaConfig['types']['Person']['columnsOverrides'] = [
    'name' => [
        'config' => [
            'eval' => 'trim',
            'readOnly' => true,
        ],
    ],
];

return $tcaConfig;
