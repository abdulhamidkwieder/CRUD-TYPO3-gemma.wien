<?php
defined('TYPO3_MODE') or die();

call_user_func(
    /**
     * @param string $extKey
     * @param string $table
     * @return void
     */
    function ($extKey, $table): void
    {
        // Plugin 'Detail'
        // tt_content.list_type = 'things_detail'
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Earlybird.Things',
            'Detail',
            'LLL:EXT:things/Resources/Private/Language/locallang.xlf:plugins.detail.title',
            'ext-things-plugin-detail'
        );

        // Disable plugin fields
        $GLOBALS['TCA'][$table]['types']['list']['subtypes_excludelist']['things_detail'] =
            'layout,select_key,pages,recursive,categories,sys_language_uid';

        // Plugin 'List'
        // tt_content.list_type = 'things_list'
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Earlybird.Things',
            'List',
            'LLL:EXT:things/Resources/Private/Language/locallang.xlf:plugins.list.title',
            'ext-things-plugin-list'
        );

        // Disable plugin fields
        $GLOBALS['TCA'][$table]['types']['list']['subtypes_excludelist']['things_list'] =
            'layout,select_key,pages,recursive,categories,sys_language_uid';
    },
    'things', 'tt_content'
);
