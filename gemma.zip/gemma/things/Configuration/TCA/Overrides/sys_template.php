<?php
defined('TYPO3_MODE') or die();

call_user_func(
    /**
     * @param string $extKey
     * @param string $table
     * @return void
     */
    function ($extKey, $table): void
    {
        // Main static TS include file
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
            $extKey,
            'Configuration/TypoScript/Static/',
            'Things'
        );
    },
    'things', 'sys_template'
);
