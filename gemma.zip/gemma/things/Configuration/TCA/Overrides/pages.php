<?php
defined('TYPO3_MODE') or die();

call_user_func(
    /**
     * @param string $extKey
     * @param string $table
     * @return void
     */
    function ($extKey, $table): void
    {
        $LLL = 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:' . $table . '.';

        /**
         * Add custom page tree folder icons
         */
        $customPageTreeFolders = [
            'things' => ['icon' => 'apps-pagetree-folder-contains-things'],
        ];
        // Add new icons
        foreach ($customPageTreeFolders as $customPageTreeFolderId => $customPageTreeFolderData) {
            if (true === isset($customPageTreeFolderData['icon'])) {
                $GLOBALS['TCA'][$table]['columns']['module']['config']['items'][] = [
                    0 => $LLL . 'module.items.' . $customPageTreeFolderId,
                    1 => $customPageTreeFolderId,
                    2 => $customPageTreeFolderData['icon'],
                ];
                $GLOBALS['TCA'][$table]['ctrl']['typeicon_classes']['contains-' . $customPageTreeFolderId] = 'apps-pagetree-folder-contains-' . $customPageTreeFolderId;
            }
        }

        // Add Page TSConfig file to 'Include Page TSConfig (from extensions)' selector
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
            $extKey,
            'Configuration/TsConfig/Page/Includes/ThingsDataRestriction.tsconfig',
            'Things: Restrict pages to schema.org thing data records'
        );
    },
    'things', 'pages'
);
