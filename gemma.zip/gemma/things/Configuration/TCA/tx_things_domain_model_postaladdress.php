<?php

$LLC = 'LLL' . ':EXT:lang/Resources/Private/Language/';
$LLB = 'LLL' . ':EXT:things/Resources/Private/Language/locallang.xlf:';
$LLL = $LLB . 'entities.postaladdress.';

$tcaConfig = [
    'ctrl' => [
        'title' => $LLL . 'label',
        'label' => 'address',
        'label_userFunc' => \Earlybird\Things\Backend\Tca\PostalAddressLabel::class . '->getLabel',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'default_sortby' => 'street ASC',
        'enablecolumns' => [
            'disabled' => 'hidden',
        ],
        'hideTable' => true,
        'searchFields' => 'street, code, locality, region, country, latitude, longitude, notes',
        'typeicon_column' => 'type',
        'typeicon_classes' => [
            'default' => 'mimetypes-ext-things-place',
        ],
        'rootLevel' => 0, // Can only exist in the page tree
    ],
    'interface' => [
        'showRecordFieldList' => 'street, code, locality, region, country, latitude, longitude, notes',
    ],
    'palettes' => [
        '10' => ['showitem' => 'street, type, --linebreak--, extended, --linebreak--, code, locality, region, country'],
        '20' => ['showitem' => 'latitude, longitude'],
        'hidden' => ['showitem' => 'hidden', 'isHiddenPalette' => true],
    ],
    'types' => [
        // Default type ('Thing')
        '1' => [
            'showitem' => '
                --palette--;;10,
                --palette--;' . $LLL . 'palettes.latlong;20,
                notes,
                --palette--;;hidden,
            ',
        ],
    ],
    'columns' => [
        'type' => [
            'exclude' => true,
            'label' => $LLL . 'type.label',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLL . 'type.options.0', 0],   // Other
                    [$LLL . 'type.options.1', 1],   // Home
                    [$LLL . 'type.options.2', 2],   // Work
                ],
            ],
        ],
        'street' => [
            'exclude' => true,
            'label' => $LLL . 'street.label',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 255,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'street.placeholder',
            ],
        ],
        'extended' => [
            'exclude' => true,
            'label' => $LLL . 'extended.label',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 255,
                'eval' => 'trim',
                'placeholder' => $LLL . 'extended.placeholder',
            ],
        ],
        'code' => [
            'exclude' => true,
            'label' => $LLL . 'code.label',
            'config' => [
                'type' => 'input',
                'size' => 5,
                'max' => 16,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'code.placeholder',
            ],
        ],
        'locality' => [
            'exclude' => true,
            'label' => $LLL . 'locality.label',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'max' => 64,
                'eval' => 'trim,required',
                'placeholder' => $LLL . 'locality.placeholder',
            ],
        ],
        'region' => [
            'exclude' => true,
            'label' => $LLL . 'region.label',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'max' => 64,
                'eval' => 'trim',
                'placeholder' => $LLL . 'region.placeholder',
            ],
        ],
        'country' => [
            'exclude' => true,
            'label' => $LLL . 'country.label',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'max' => 64,
                'eval' => 'trim',
                'placeholder' => $LLL . 'country.placeholder',
            ],
        ],
        'latitude' => [
            'exclude' => true,
            'label' => $LLL . 'latitude.label',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'eval' => 'double2',
                'placeholder' => $LLL . 'latitude.placeholder',
            ],
        ],
        'longitude' => [
            'exclude' => true,
            'label' => $LLL . 'longitude.label',
            'config' => [
                'type' => 'input',
                'size' => 20,
                'eval' => 'double2',
                'placeholder' => $LLL . 'longitude.placeholder',
            ],
        ],
        'notes' => [
            'exclude' => true,
            'label' => $LLB . 'globals.notes.label',
            'config' => [
                'type' => 'text',
                'cols' => 80,
                'rows' => 2,
                'max' => 255,
                'eval' => 'trim',
            ],
        ],
        // We use this field as dummy for the BE label.
        // Note: It must exist as field in the DB to use TCA n:1 relations (e.g. select single)
        'address' => [
            'exclude' => false,
            'label' => $LLL . 'label',
            'config' => [
                'type' => 'none',
            ],
        ],

        // TYPO3 internal fields
        // Note: The order in which you define fields affects various sections in the BE
        //       (e.g. 'Set fields' in list view). Thus move more important fields up
        //       and less often used fields down :)
        'hidden' => [
            'exclude' => true,
            'label' => $LLC . 'locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => $LLC . 'locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'sorting_foreign' => [
            'exclude' => false,
            'label' => 'sorting_foreign',
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];

// $tcaConfig['ctrl']['delete'] = 'deleted';

return $tcaConfig;
