<?php

$LLC = 'LLL' . ':EXT:lang/Resources/Private/Language/';
$LLB = 'LLL' . ':EXT:things/Resources/Private/Language/locallang.xlf:';
$LLL = $LLB . 'entities.emailaddress.';

$tcaConfig = [
    'ctrl' => [
        'title' => $LLL . 'label',
        'label' => 'email',
        'label_userFunc' => \Earlybird\Things\Backend\Tca\EmailAddressLabel::class . '->getLabel',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'default_sortby' => 'email ASC, uid ASC',
        'enablecolumns' => [
            'disabled' => 'hidden',
        ],
        'hideTable' => true,
        'searchFields' => 'email, notes',
        'typeicon_column' => 'type',
        'typeicon_classes' => [
            'default' => 'mimetypes-ext-things-email',
        ],
        'rootLevel' => 0, // Can only exist in the page tree
    ],
    'interface' => [
        'showRecordFieldList' => 'email, type, notes',
    ],
    'palettes' => [
        '10' => ['showitem' => 'email, type, --linebreak--, notes'],
        'hidden' => ['showitem' => 'hidden', 'isHiddenPalette' => true],
    ],
    'types' => [
        // Default type ('Thing')
        '1' => [
            'showitem' => '
                --palette--;;10,
                --palette--;;hidden,
            ',
        ],
    ],
    'columns' => [
        'email' => [
            'exclude' => true,
            'label' => $LLL . 'email.label',
            'config' => [
                'type' => 'input',
                'size' => 50,
                'max' => 64,
                'eval' => 'trim,required,email',
                'placeholder' => $LLL . 'email.placeholder',
            ],
        ],
        'type' => [
            'exclude' => true,
            'label' => $LLL . 'type.label',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    [$LLL . 'type.options.0', 0],   // Other
                    [$LLL . 'type.options.1', 1],   // Home
                    [$LLL . 'type.options.2', 2],   // Work
                ],
            ],
        ],
        'notes' => [
            'exclude' => true,
            'label' => $LLB . 'globals.notes.label',
            'config' => [
                'type' => 'text',
                'cols' => 80,
                'rows' => 2,
                'max' => 255,
                'eval' => 'trim',
            ],
        ],

        // TYPO3 internal fields
        // Note: The order in which you define fields affects various sections in the BE
        //       (e.g. 'Set fields' in list view). Thus move more important fields up
        //       and less often used fields down :)
        'hidden' => [
            'exclude' => true,
            'label' => $LLC . 'locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => $LLC . 'locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'sorting_foreign' => [
            'exclude' => false,
            'label' => 'sorting_foreign',
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];

// $tcaConfig['ctrl']['delete'] = 'deleted';

return $tcaConfig;
