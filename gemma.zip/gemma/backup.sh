#!/bin/bash
CURRENT=`pwd`
PROJECTTITLE=`basename "$CURRENT"`

function backup {
  if [ -d "${PWD}/backup" ]
   then
     docker-compose exec --user www-admin $PROJECTTITLE /tools/global/scripts/backup.sh
   else
    printf "${C_ERROR}$PWD/backup not found.${C_RESET}\n"
    exit 1
  fi
}
backup
